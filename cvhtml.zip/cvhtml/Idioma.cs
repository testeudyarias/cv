using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cvhtml
{
    public class Idioma
    {
        public string Nombre { get; set; }
        public decimal Nivel { get; set; }
        
    }
}