using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace cvhtml
{
    public class Estudio
    {
        public string Nombre { get; set; }
        public string Detalle { get; set; }
        public string Periodo { get; set; }
        public string Institucion { get; set; }
        
    }
}